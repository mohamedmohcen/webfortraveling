import { Destination } from '../types';

export const destinations: Destination[] = [
  {
    id: '1',
    name: 'دبي',
    description: 'استمتع بتجربة فريدة في مدينة الأحلام',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c',
    price: 3500,
    duration: '5 أيام',
    rating: 4.8,
    activities: ['تسوق', 'سفاري', 'برج خليفة'],
  },
  {
    id: '2',
    name: 'المالديف',
    description: 'جزر استوائية خلابة ومياه فيروزية',
    image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8',
    price: 6000,
    duration: '7 أيام',
    rating: 4.9,
    activities: ['غوص', 'سباحة', 'رحلات بحرية'],
  },
  {
    id: '3',
    name: 'تركيا',
    description: 'تاريخ عريق وثقافة غنية',
    image: 'https://images.unsplash.com/photo-1524231757912-21f4fe3a7200',
    price: 2800,
    duration: '6 أيام',
    rating: 4.7,
    activities: ['سياحة ثقافية', 'تسوق', 'مناطيد'],
  },
];