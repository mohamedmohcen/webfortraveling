import { useState } from 'react';
import { Destination } from '../types';

export const useBooking = () => {
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [bookingStep, setBookingStep] = useState(1);
  const [bookingDetails, setBookingDetails] = useState({
    travelers: 1,
    date: '',
    roomType: 'standard',
    addons: [] as string[]
  });

  const handleBooking = (destination: Destination) => {
    setSelectedDestination(destination);
    setBookingStep(1);
  };

  const updateBookingDetails = (details: Partial<typeof bookingDetails>) => {
    setBookingDetails(prev => ({ ...prev, ...details }));
  };

  const nextStep = () => setBookingStep(prev => prev + 1);
  const prevStep = () => setBookingStep(prev => prev - 1);

  return {
    selectedDestination,
    bookingStep,
    bookingDetails,
    handleBooking,
    updateBookingDetails,
    nextStep,
    prevStep
  };
};