import React, { useState } from 'react';
import { Star } from 'lucide-react';
import { Button } from './ui/Button';
import { BookingModal } from './booking/BookingModal';
import { Destination } from '../types';
import { useBooking } from '../hooks/useBooking';

interface DestinationCardProps {
  destination: Destination;
}

export const DestinationCard = ({ destination }: DestinationCardProps) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { handleBooking } = useBooking();

  const onBookNow = () => {
    handleBooking(destination);
    setIsModalOpen(true);
  };

  return (
    <>
      <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
        <div className="relative h-48">
          <img
            src={destination.image}
            alt={destination.name}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-2">{destination.name}</h3>
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-1">
              <Star className="text-yellow-400 fill-current" size={20} />
              <span>{destination.rating}</span>
            </div>
            <span className="text-gray-600">{destination.duration}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <Button onClick={onBookNow}>احجز الآن</Button>
            <span className="text-lg font-bold">{destination.price} ريال</span>
          </div>
        </div>
      </div>

      <BookingModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </>
  );
};