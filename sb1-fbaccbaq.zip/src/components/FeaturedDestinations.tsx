import React from 'react';
import { Container } from './ui/Container';
import { DestinationCard } from './DestinationCard';
import { destinations } from '../data/destinations';

export const FeaturedDestinations = () => {
  return (
    <section className="py-16 bg-gray-50">
      <Container>
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">الوجهات المميزة</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {destinations.map((destination) => (
            <DestinationCard key={destination.id} destination={destination} />
          ))}
        </div>
      </Container>
    </section>
  );
};