import React from 'react';
import { Button } from '../ui/Button';
import { useBooking } from '../../hooks/useBooking';

interface BookingFormProps {
  onNext: () => void;
}

export const BookingForm = ({ onNext }: BookingFormProps) => {
  const { bookingDetails, updateBookingDetails, selectedDestination } = useBooking();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          عدد المسافرين
        </label>
        <input
          type="number"
          min="1"
          value={bookingDetails.travelers}
          onChange={(e) => updateBookingDetails({ travelers: parseInt(e.target.value) })}
          className="w-full p-3 border rounded-lg"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          تاريخ السفر
        </label>
        <input
          type="date"
          value={bookingDetails.date}
          onChange={(e) => updateBookingDetails({ date: e.target.value })}
          className="w-full p-3 border rounded-lg"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          نوع الغرفة
        </label>
        <select
          value={bookingDetails.roomType}
          onChange={(e) => updateBookingDetails({ roomType: e.target.value })}
          className="w-full p-3 border rounded-lg"
        >
          <option value="standard">قياسية</option>
          <option value="deluxe">ديلوكس</option>
          <option value="suite">جناح</option>
        </select>
      </div>

      <Button type="submit" className="w-full">
        التالي
      </Button>
    </form>
  );
};