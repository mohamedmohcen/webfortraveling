import React, { useState } from 'react';
import { Button } from '../ui/Button';
import { useBooking } from '../../hooks/useBooking';

interface PaymentFormProps {
  onNext: () => void;
  onBack: () => void;
}

export const PaymentForm = ({ onNext, onBack }: PaymentFormProps) => {
  const [paymentDetails, setPaymentDetails] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    name: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          رقم البطاقة
        </label>
        <input
          type="text"
          value={paymentDetails.cardNumber}
          onChange={(e) => setPaymentDetails({ ...paymentDetails, cardNumber: e.target.value })}
          className="w-full p-3 border rounded-lg"
          placeholder="0000 0000 0000 0000"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            تاريخ الانتهاء
          </label>
          <input
            type="text"
            value={paymentDetails.expiryDate}
            onChange={(e) => setPaymentDetails({ ...paymentDetails, expiryDate: e.target.value })}
            className="w-full p-3 border rounded-lg"
            placeholder="MM/YY"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            رمز الأمان
          </label>
          <input
            type="text"
            value={paymentDetails.cvv}
            onChange={(e) => setPaymentDetails({ ...paymentDetails, cvv: e.target.value })}
            className="w-full p-3 border rounded-lg"
            placeholder="CVV"
          />
        </div>
      </div>

      <div className="flex gap-4">
        <Button type="button" variant="secondary" onClick={onBack} className="w-full">
          رجوع
        </Button>
        <Button type="submit" className="w-full">
          تأكيد الدفع
        </Button>
      </div>
    </form>
  );
};