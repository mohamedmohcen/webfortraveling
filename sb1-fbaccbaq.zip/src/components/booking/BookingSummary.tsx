import React from 'react';
import { Check } from 'lucide-react';
import { Button } from '../ui/Button';
import { useBooking } from '../../hooks/useBooking';

interface BookingSummaryProps {
  onFinish: () => void;
  onBack: () => void;
}

export const BookingSummary = ({ onFinish, onBack }: BookingSummaryProps) => {
  const { selectedDestination, bookingDetails } = useBooking();

  if (!selectedDestination) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-center mb-8">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
          <Check className="text-green-600" size={32} />
        </div>
      </div>

      <h3 className="text-xl font-semibold text-center mb-6">
        تم تأكيد حجزك بنجاح!
      </h3>

      <div className="bg-gray-50 p-6 rounded-lg space-y-4">
        <div className="flex justify-between">
          <span className="text-gray-600">الوجهة:</span>
          <span className="font-semibold">{selectedDestination.name}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">عدد المسافرين:</span>
          <span className="font-semibold">{bookingDetails.travelers}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">تاريخ السفر:</span>
          <span className="font-semibold">{bookingDetails.date}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">نوع الغرفة:</span>
          <span className="font-semibold">{bookingDetails.roomType}</span>
        </div>
      </div>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={onBack} className="w-full">
          رجوع
        </Button>
        <Button onClick={onFinish} className="w-full">
          إنهاء
        </Button>
      </div>
    </div>
  );
};