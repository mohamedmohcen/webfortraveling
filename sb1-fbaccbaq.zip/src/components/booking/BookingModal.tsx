import React from 'react';
import { X } from 'lucide-react';
import { Button } from '../ui/Button';
import { BookingForm } from './BookingForm';
import { PaymentForm } from './PaymentForm';
import { BookingSummary } from './BookingSummary';
import { useBooking } from '../../hooks/useBooking';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BookingModal = ({ isOpen, onClose }: BookingModalProps) => {
  const { bookingStep, selectedDestination, bookingDetails, nextStep, prevStep } = useBooking();

  if (!isOpen || !selectedDestination) return null;

  const steps = [
    {
      title: 'تفاصيل الحجز',
      component: <BookingForm onNext={nextStep} />
    },
    {
      title: 'الدفع',
      component: <PaymentForm onNext={nextStep} onBack={prevStep} />
    },
    {
      title: 'ملخص الحجز',
      component: <BookingSummary onFinish={onClose} onBack={prevStep} />
    }
  ];

  const currentStep = steps[bookingStep - 1];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-2xl mx-4">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold">{currentStep.title}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-6">
          {currentStep.component}
        </div>
      </div>
    </div>
  );
};