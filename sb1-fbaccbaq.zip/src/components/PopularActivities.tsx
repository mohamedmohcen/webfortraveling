import React from 'react';
import { Container } from './ui/Container';
import { Compass, ShoppingBag, Palmtree, Mountain } from 'lucide-react';

const activities = [
  {
    icon: Palmtree,
    title: 'شواطئ',
    description: 'استمتع بأجمل الشواطئ حول العالم'
  },
  {
    icon: Mountain,
    title: 'مغامرات',
    description: 'اكتشف تجارب مثيرة ومغامرات لا تنسى'
  },
  {
    icon: Compass,
    title: 'سياحة ثقافية',
    description: 'تعرف على ثقافات وحضارات مختلفة'
  },
  {
    icon: ShoppingBag,
    title: 'تسوق',
    description: 'زر أفضل وجهات التسوق العالمية'
  }
];

export const PopularActivities = () => {
  return (
    <section className="py-16 bg-white">
      <Container>
        <h2 className="text-3xl font-bold text-center mb-12">الأنشطة المميزة</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {activities.map((activity, index) => {
            const Icon = activity.icon;
            return (
              <div 
                key={index}
                className="text-center p-6 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 text-blue-600 mb-4">
                  <Icon size={32} />
                </div>
                <h3 className="text-xl font-semibold mb-2">{activity.title}</h3>
                <p className="text-gray-600">{activity.description}</p>
              </div>
            );
          })}
        </div>
      </Container>
    </section>
  );
};