import React from 'react';
import { Menu, Globe, User } from 'lucide-react';
import { Container } from './ui/Container';
import { Button } from './ui/Button';

export const Navbar = () => {
  return (
    <nav className="bg-white shadow-md">
      <Container>
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-reverse space-x-4">
            <button className="lg:hidden">
              <Menu size={24} />
            </button>
            <div className="text-2xl font-bold text-blue-600">رحلاتي</div>
          </div>

          <div className="hidden lg:flex items-center space-x-reverse space-x-8">
            <a href="#" className="text-gray-700 hover:text-blue-600">الرئيسية</a>
            <a href="#" className="text-gray-700 hover:text-blue-600">الوجهات</a>
            <a href="#" className="text-gray-700 hover:text-blue-600">العروض</a>
            <a href="#" className="text-gray-700 hover:text-blue-600">من نحن</a>
            <a href="#" className="text-gray-700 hover:text-blue-600">اتصل بنا</a>
          </div>

          <div className="flex items-center space-x-reverse space-x-4">
            <Button variant="secondary" icon={Globe}>العربية</Button>
            <Button variant="secondary" icon={User}>تسجيل الدخول</Button>
          </div>
        </div>
      </Container>
    </nav>
  );
};