import React, { useState } from 'react';
import { Search, Calendar, MapPin, Tag } from 'lucide-react';
import { Button } from './ui/Button';
import { Container } from './ui/Container';
import { SearchFilters } from '../types';

export const SearchSection = () => {
  const [filters, setFilters] = useState<SearchFilters>({
    destination: '',
    startDate: '',
    endDate: '',
    activity: ''
  });

  const handleSearch = () => {
    console.log('Search filters:', filters);
  };

  return (
    <div className="bg-white shadow-lg rounded-lg -mt-8 relative z-20 mx-4">
      <Container>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="relative">
              <MapPin className="absolute right-3 top-3 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="الوجهة"
                className="w-full pr-10 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={filters.destination}
                onChange={(e) => setFilters({ ...filters, destination: e.target.value })}
              />
            </div>
            
            <div className="relative">
              <Calendar className="absolute right-3 top-3 text-gray-400" size={20} />
              <input
                type="date"
                className="w-full pr-10 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={filters.startDate}
                onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
              />
            </div>
            
            <div className="relative">
              <Tag className="absolute right-3 top-3 text-gray-400" size={20} />
              <select
                className="w-full pr-10 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 appearance-none"
                value={filters.activity}
                onChange={(e) => setFilters({ ...filters, activity: e.target.value })}
              >
                <option value="">نوع النشاط</option>
                <option value="beach">شاطئ</option>
                <option value="culture">ثقافة</option>
                <option value="adventure">مغامرات</option>
                <option value="shopping">تسوق</option>
              </select>
            </div>
            
            <Button 
              icon={Search}
              className="w-full"
              onClick={handleSearch}
            >
              بحث
            </Button>
          </div>
        </div>
      </Container>
    </div>
  );
};