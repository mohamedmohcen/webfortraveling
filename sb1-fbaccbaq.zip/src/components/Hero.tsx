import React from 'react';
import { Container } from './ui/Container';

export const Hero = () => {
  return (
    <div className="relative h-[600px] flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1682687220742-aba13b6e50ba")',
        }}
      >
        <div className="absolute inset-0 bg-black/50" />
      </div>
      
      <Container className="relative z-10">
        <div className="text-center text-white">
          <h1 className="text-5xl font-bold mb-6">اكتشف العالم معنا</h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            رحلات استثنائية تناسب كل الأذواق والميزانيات. اختر وجهتك المفضلة واستمتع بتجربة سفر لا تُنسى
          </p>
        </div>
      </Container>
    </div>
  );
};