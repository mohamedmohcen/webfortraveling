import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SearchSection } from './components/SearchSection';
import { FeaturedDestinations } from './components/FeaturedDestinations';
import { PopularActivities } from './components/PopularActivities';
import { Reviews } from './components/Reviews';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <Hero />
      <SearchSection />
      <FeaturedDestinations />
      <PopularActivities />
      <Reviews />
    </div>
  );
}

export default App;