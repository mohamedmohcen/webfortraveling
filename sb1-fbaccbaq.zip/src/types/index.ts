export interface Destination {
  id: string;
  name: string;
  description: string;
  image: string;
  price: number;
  duration: string;
  rating: number;
  activities: string[];
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface SearchFilters {
  destination: string;
  startDate: string;
  endDate: string;
  activity: string;
}